function submitForm() {

    var tabToNavigate = document.getElementById("v-pills-profile-tab");
  
  
    tabToNavigate.click();
  }
  function submitForm1() {
  
    var tabToNavigate = document.getElementById("v-pills-messages-tab");
  
    tabToNavigate.click();
  }
  
  
  